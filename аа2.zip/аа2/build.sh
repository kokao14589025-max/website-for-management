#!/bin/bash

echo "Building Minecraft Player Admin Plugin..."
echo

# Check if Maven is installed
if ! command -v mvn &> /dev/null; then
    echo "Error: Maven is not installed or not in PATH"
    echo "Please install Maven from https://maven.apache.org/"
    exit 1
fi

# Build the plugin
echo "Building plugin..."
cd plugin
mvn clean package
if [ $? -ne 0 ]; then
    echo "Error: Failed to build plugin"
    exit 1
fi

echo
echo "Build completed successfully!"
echo "JAR file location: plugin/target/PlayerAdminPlugin-1.31.8.jar"
echo
echo "Next steps:"
echo "1. Copy the JAR file to your server's plugins folder"
echo "2. Start your server"
echo "3. Open website/index.html in your browser"
echo
