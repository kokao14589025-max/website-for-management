package com.minecraft.admin;

import com.minecraft.admin.api.PlayerAdminAPI;
import com.minecraft.admin.commands.PlayerAdminCommand;
import com.minecraft.admin.listeners.PlayerListener;
import com.minecraft.admin.web.WebServer;
import org.bukkit.plugin.java.JavaPlugin;

public class PlayerAdminPlugin extends JavaPlugin {
    
    private static PlayerAdminPlugin instance;
    private PlayerAdminAPI api;
    private WebServer webServer;
    
    @Override
    public void onEnable() {
        instance = this;
        
        // Save default config
        saveDefaultConfig();
        
        // Initialize API
        api = new PlayerAdminAPI(this);
        
        // Register commands
        getCommand("playeradmin").setExecutor(new PlayerAdminCommand(this));
        
        // Register listeners
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        
        // Start web server
        int port = getConfig().getInt("web.port", 8080);
        webServer = new WebServer(port, api);
        
        try {
            webServer.start();
            getLogger().info("Web server started on port " + port);
        } catch (Exception e) {
            getLogger().severe("Failed to start web server: " + e.getMessage());
            e.printStackTrace();
        }
        
        getLogger().info("PlayerAdminPlugin has been enabled!");
    }
    
    @Override
    public void onDisable() {
        if (webServer != null) {
            webServer.stop();
            getLogger().info("Web server stopped");
        }
        
        getLogger().info("PlayerAdminPlugin has been disabled!");
    }
    
    public static PlayerAdminPlugin getInstance() {
        return instance;
    }
    
    public PlayerAdminAPI getAPI() {
        return api;
    }
    
    public WebServer getWebServer() {
        return webServer;
    }
}
