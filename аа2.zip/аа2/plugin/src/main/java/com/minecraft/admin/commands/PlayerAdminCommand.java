package com.minecraft.admin.commands;

import com.minecraft.admin.PlayerAdminPlugin;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class PlayerAdminCommand implements CommandExecutor {
    
    private final PlayerAdminPlugin plugin;
    
    public PlayerAdminCommand(PlayerAdminPlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("playeradmin.admin")) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to use this command!");
            return true;
        }
        
        if (args.length == 0) {
            sender.sendMessage(ChatColor.YELLOW + "PlayerAdmin Plugin Commands:");
            sender.sendMessage(ChatColor.GREEN + "/playeradmin reload" + ChatColor.WHITE + " - Reload the plugin");
            sender.sendMessage(ChatColor.GREEN + "/playeradmin status" + ChatColor.WHITE + " - Show plugin status");
            sender.sendMessage(ChatColor.GREEN + "/playeradmin web" + ChatColor.WHITE + " - Show web interface info");
            sender.sendMessage(ChatColor.GREEN + "/playeradmin code" + ChatColor.WHITE + " - Generate server code");
            sender.sendMessage(ChatColor.GREEN + "/playeradmin code list" + ChatColor.WHITE + " - Show code information");
            return true;
        }
        
        switch (args[0].toLowerCase()) {
            case "reload":
                plugin.reloadConfig();
                sender.sendMessage(ChatColor.GREEN + "Plugin configuration reloaded!");
                break;
                
            case "status":
                sender.sendMessage(ChatColor.YELLOW + "PlayerAdmin Plugin Status:");
                sender.sendMessage(ChatColor.GREEN + "Web Server: " + 
                    (plugin.getWebServer() != null ? "Running" : "Stopped"));
                sender.sendMessage(ChatColor.GREEN + "Online Players: " + 
                    plugin.getAPI().getOnlinePlayers().size());
                break;
                
            case "web":
                int port = plugin.getConfig().getInt("web.port", 8080);
                sender.sendMessage(ChatColor.YELLOW + "Web Interface:");
                sender.sendMessage(ChatColor.GREEN + "URL: http://localhost:" + port);
                sender.sendMessage(ChatColor.GREEN + "No authentication required");
                break;
                
            case "code":
                if (args.length > 1 && args[1].equalsIgnoreCase("list")) {
                    // Показать список активных кодов
                    sender.sendMessage(ChatColor.YELLOW + "Active Server Codes:");
                    sender.sendMessage(ChatColor.GREEN + "Use /playeradmin code to generate a new code");
                    sender.sendMessage(ChatColor.GRAY + "Codes are generated dynamically and change each time.");
                } else {
                    // Генерировать новый код
                    String serverCode = generateServerCode();
                    sender.sendMessage(ChatColor.YELLOW + "🔑 Server Code Generated:");
                    sender.sendMessage("");
                    sender.sendMessage(ChatColor.GREEN + "Code: " + ChatColor.WHITE + ChatColor.BOLD + serverCode);
                    sender.sendMessage("");
                    sender.sendMessage(ChatColor.GREEN + "📋 Instructions for players:");
                    sender.sendMessage(ChatColor.WHITE + "1. Open the web interface");
                    sender.sendMessage(ChatColor.WHITE + "2. Enter this code in the 'Server Code' field");
                    sender.sendMessage(ChatColor.WHITE + "3. Click '🔑 Find by Code'");
                    sender.sendMessage(ChatColor.WHITE + "4. The system will automatically connect!");
                    sender.sendMessage("");
                    sender.sendMessage(ChatColor.GRAY + "💡 Tip: Share this code with your players for easy access!");
                }
                break;
                
            default:
                sender.sendMessage(ChatColor.RED + "Unknown command! Use /playeradmin for help.");
                break;
        }
        
        return true;
    }
    
    private String generateServerCode() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder code = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            code.append(chars.charAt((int) (Math.random() * chars.length())));
        }
        return code.toString();
    }
}
