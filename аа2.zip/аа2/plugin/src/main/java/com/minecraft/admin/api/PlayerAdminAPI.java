package com.minecraft.admin.api;

import com.minecraft.admin.PlayerAdminPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PlayerAdminAPI {
    
    private final PlayerAdminPlugin plugin;
    
    public PlayerAdminAPI(PlayerAdminPlugin plugin) {
        this.plugin = plugin;
    }
    
    public List<PlayerInfo> getOnlinePlayers() {
        List<PlayerInfo> players = new ArrayList<>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            players.add(new PlayerInfo(player));
        }
        return players;
    }
    
    public PlayerInfo getPlayerInfo(String playerName) {
        Player player = Bukkit.getPlayer(playerName);
        if (player != null) {
            return new PlayerInfo(player);
        }
        return null;
    }
    
    public boolean kickPlayer(String playerName, String reason) {
        Player player = Bukkit.getPlayer(playerName);
        if (player != null) {
            player.kickPlayer(reason);
            return true;
        }
        return false;
    }
    
    public boolean banPlayer(String playerName, String reason) {
        Player player = Bukkit.getPlayer(playerName);
        if (player != null) {
            Bukkit.getBanList(org.bukkit.BanList.Type.NAME).addBan(playerName, reason, null, null);
            player.kickPlayer("You have been banned: " + reason);
            return true;
        }
        return false;
    }
    
    public boolean teleportPlayer(String playerName, double x, double y, double z, String world) {
        Player player = Bukkit.getPlayer(playerName);
        if (player != null) {
            Location location = new Location(Bukkit.getWorld(world), x, y, z);
            player.teleport(location);
            return true;
        }
        return false;
    }
    
    public boolean giveItem(String playerName, String itemName, int amount) {
        Player player = Bukkit.getPlayer(playerName);
        if (player != null) {
            try {
                org.bukkit.Material material = org.bukkit.Material.valueOf(itemName.toUpperCase());
                org.bukkit.inventory.ItemStack item = new org.bukkit.inventory.ItemStack(material, amount);
                player.getInventory().addItem(item);
                return true;
            } catch (IllegalArgumentException e) {
                return false;
            }
        }
        return false;
    }
    
    public boolean setHealth(String playerName, double health) {
        Player player = Bukkit.getPlayer(playerName);
        if (player != null) {
            player.setHealth(Math.min(health, player.getMaxHealth()));
            return true;
        }
        return false;
    }
    
    public boolean setFood(String playerName, int food) {
        Player player = Bukkit.getPlayer(playerName);
        if (player != null) {
            player.setFoodLevel(Math.min(food, 20));
            return true;
        }
        return false;
    }
    
    public boolean addEffect(String playerName, String effectName, int duration, int amplifier) {
        Player player = Bukkit.getPlayer(playerName);
        if (player != null) {
            try {
                PotionEffectType effectType = PotionEffectType.getByName(effectName.toUpperCase());
                if (effectType != null) {
                    PotionEffect effect = new PotionEffect(effectType, duration * 20, amplifier);
                    player.addPotionEffect(effect);
                    return true;
                }
            } catch (Exception e) {
                return false;
            }
        }
        return false;
    }
    
    public boolean sendMessage(String playerName, String message) {
        Player player = Bukkit.getPlayer(playerName);
        if (player != null) {
            player.sendMessage(message);
            return true;
        }
        return false;
    }
    
    public boolean executeCommand(String command) {
        try {
            Bukkit.getScheduler().runTask(plugin, () -> {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
            });
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    public static class PlayerInfo {
        private final String name;
        private final UUID uuid;
        private final double health;
        private final int food;
        private final Location location;
        private final String gameMode;
        private final boolean online;
        
        public PlayerInfo(Player player) {
            this.name = player.getName();
            this.uuid = player.getUniqueId();
            this.health = player.getHealth();
            this.food = player.getFoodLevel();
            this.location = player.getLocation();
            this.gameMode = player.getGameMode().name();
            this.online = player.isOnline();
        }
        
        // Getters
        public String getName() { return name; }
        public UUID getUuid() { return uuid; }
        public double getHealth() { return health; }
        public int getFood() { return food; }
        public Location getLocation() { return location; }
        public String getGameMode() { return gameMode; }
        public boolean isOnline() { return online; }
    }
}

