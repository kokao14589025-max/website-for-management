package com.minecraft.admin.listeners;

import com.minecraft.admin.PlayerAdminPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerListener implements Listener {
    
    private final PlayerAdminPlugin plugin;
    
    public PlayerListener(PlayerAdminPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        // Log player join for web interface
        plugin.getLogger().info("Player " + event.getPlayer().getName() + " joined the server");
    }
    
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        // Log player quit for web interface
        plugin.getLogger().info("Player " + event.getPlayer().getName() + " left the server");
    }
}

